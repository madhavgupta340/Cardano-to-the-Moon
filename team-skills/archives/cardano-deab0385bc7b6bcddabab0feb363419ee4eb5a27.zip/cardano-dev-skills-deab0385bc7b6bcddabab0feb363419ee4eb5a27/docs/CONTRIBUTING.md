# Contributing to Cardano Dev Skills

This guide covers source vetting, adding sources, adding skills, Claude/Codex
compatibility, refresh, documentation governance, and quality standards.

## One contribution, two agents

Claude Code and Codex consume the same files under `skills/`. Do not maintain
host-specific copies of a workflow or reference. The canonical portability
rules live in [AGENT_COMPATIBILITY.md](AGENT_COMPATIBILITY.md); read them before
changing a skill, either plugin manifest, discovery links, agent instructions,
or their validation.

The important boundary is:

- shared behavior and Cardano knowledge remain agent-neutral in `skills/`;
- `.claude-plugin/` and `CLAUDE.md` adapt that content to Claude;
- `.codex-plugin/`, `.agents/skills`, and `AGENTS.md` adapt it to Codex;
- `hooks/` supplies optional SessionStart context in a shared output format;
- `scripts/validate.py` checks the shared contract and both adapters together.

Claude's `allowed-tools` and `disallowed-tools` frontmatter fields remain
required by this repository's security policy, but Codex does not use them as
the shared behavioral contract. State every required safety rule in the
Markdown body as well. Resolve bundled documentation relative to the active
`SKILL.md`; never use `${CLAUDE_SKILL_DIR}` or `${CLAUDE_PLUGIN_ROOT}` in a
shared skill body.

Skills remain useful with local access. A public read-only evidence exception
requires a recorded DESIGN decision, unchanged least-privilege frontmatter, a
body-level request and untrusted-data boundary, precise provenance, and a
targeted fallback for host denial. Claude domain settings and Codex network
permissions are separate host controls; never claim either capability always
exists or change an allowlist automatically.

## Scope: what belongs in this repo

This repo teaches **building on Cardano**. It is a generic knowledge base for AI coding agents and developers.

The repo has two layers with different rules:

- **Sources** (`registry/sources.yaml` → `docs/sources/`) are mirrored upstream documentation: the project's own words, vetted for relevance and maintenance, kept current by the weekly refresh.
- **Skills** (`skills/`) are authored by this repo's maintainers: task-oriented behavioral guidance. Skills are never project-specific — projects are documented as sources and taught through task skills.

### Source scope: the two-part test

A source qualifies only if it passes **both** gates:

1. **Cardano-native.** The project's on-chain footprint is on Cardano — contracts deployed there, or specs/standards targeting it. Multichain projects qualify only if Cardano is a first-class supported chain, and only the Cardano-relevant part of their docs is mirrored (use `glob_patterns`). We don't list AI platforms operating on other chains, or oracles that don't operate on Cardano — however established they are.
2. **Developer-integration surface.** The docs must document something a developer building on Cardano integrates with or builds on: contracts, APIs, SDKs, protocol specs, a runnable node or service. An *integration-first* project (an oracle, a payment protocol, an indexer) qualifies even though it is a branded, for-profit product — its business only exists if developers integrate it, so its docs are developer material. An end-product user manual (how to swap on a DEX frontend, how to browse an NFT marketplace site) does not qualify; the same project's protocol or contract specs can qualify even when its end-product docs don't.

Always out of scope regardless: closed-source content; marketing-only material.

In-scope examples: SDKs, frameworks, validator libraries, design patterns, language tooling; infrastructure (nodes, indexers, chain providers); protocol and standard specs (CIPs, ledger specs); reference implementations of *patterns*; generic dApp categories (DEX, lending, NFT marketplace, oracle consumer, governance tool).

### Skill scope

Skills are this repo's editorial voice and are held to a **stricter bar than sources**:

- **No project-specific or brand-named skills, ever.** Skills map to developer workflows (see DESIGN.md Decision 2) — `query-chain`, not the name of a chain provider. This is stricter than the source rules on purpose: a skill is behavioral instruction an agent follows (tool use, workflow steps, decision criteria), so a harmful or stale skill can do more damage than a harmful doc. Vendor-maintained skills copied here inevitably drift from their canonical home. Vendors who maintain their own installable skill should document it in their own docs — once those docs are a registered source, agents and users discover the skill there, always via the refreshed pointer.
- **Plugin meta-skills are the one recorded exception.** A meta-skill acts on the plugin itself rather than teaching a Cardano workflow — either by configuring the environment the plugin runs in (`cardano-context`, DESIGN.md Decision 12) or by carrying information back to its maintainers (`give-feedback`, Decision 14). The second kind is a deliberate widening of the category: Decision 12's original tests (modifies the environment, run once per project, idempotent, distributes via git) describe `cardano-context` and none of them fit `give-feedback`, so the first is a grandfather rather than a precedent. A new meta-skill of either kind needs its own decision in DESIGN.md before it is written.
- **A skill that teaches integrating with a specific project requires that project to be a registered source.** Spec-level detail (endpoints, request bodies, datum schemas) belongs in `docs/sources/`, where the weekly refresh keeps it current; a skill's `references/` directory is for behavioral guidance, not pasted specs.
- **Renaming a brand-named skill is not, by itself, a path to acceptance.** Whether the repo wants a new task skill is an editorial decision — open a discussion proposing it before writing code. Registering the project's docs as a source needs no discussion.
- **Skills must survey, not steer.** Where multiple implementations of a pattern exist, a skill presents them neutrally with honest decision criteria (`query-chain` is the model). The more directly adoption routes revenue to a project (metered APIs, protocol fees, marketplace take-rates), the higher this bar, and the stronger the preference for the docs-as-source path over skill content. Project-specific skills are additionally rejected on structural grounds regardless of author or intent: they duplicate content whose canonical home is elsewhere, they put executable behavioral instructions (higher risk than docs) under a brand's control, and their `references/` content has no refresh mechanism and rots silently.

If you're unsure whether something fits, open a discussion before writing code.

## Source-vetting policy

Before adding any new entry to `registry/sources.yaml`, verify the upstream repo is actively maintained:

1. **Last commit < 6 months old**
2. **No archived / deprecated / sunset banner** in README or repo settings
3. **For forks**, pick the maintained canonical (concrete example: Evolution SDK is the live fork of dead Lucid Evolution — always prefer the live one)

If signals are ambiguous (e.g. low commit frequency but a stable mature library; deprecation notice with unclear successor), flag it in the PR rather than guess.

**Document-of-record exception.** The recency rule measures maintenance cadence, which is meaningless for a repo whose only job is to mirror a document that changes rarely by design (e.g. the Cardano Constitution, amended only by on-chain governance action). Waiving it takes two things in the same PR, and both are required: the registry entry carries a `vetting_exception` reason string, **and** the source is granted the waiver in `VETTING_EXCEPTIONS` in `scripts/validate.py`, mapped to the repo it was granted for. An entry carrying the field without a matching grant fails the `validate` check. The reason must explain why cadence is uninformative *and* what does guarantee currency (for the Constitution: the on-chain anchor hash). With the grant in place the policy check waives the recency rule for that source (the archived and fork checks still apply) and surfaces the waiver as a warning in the PR check output.

The grant is what makes the waiver a decision rather than a default. A reason string alone is self-service — any entry could carry one, and the maintenance bar would stop applying to it before anyone had to agree. Naming the source in the script makes granting a waiver a code change a maintainer reviews alongside the source it covers, the same shape as `ALLOWED_TOOLS_EXCEPTIONS` in the same file. The grant records the repo as well as the name, so repointing a waived entry at a different upstream re-enters vetting instead of inheriting the waiver.

The same bar applies to the candidate entries at the bottom of `registry/sources.yaml` — don't promote a candidate without re-vetting against this bar.

## Automated PR policy checks

PRs that touch `skills/`, `registry/`, or `docs/sources/` run
`.github/workflows/pr-policy.yml`, which has two layers. The existing
`.github/workflows/validate.yml` is the separate shared correctness gate and
checks skill portability plus both Claude and Codex adapters; these concerns
belong in one job because a shared skill is the shipped unit.

1. **Mechanical checks** (`scripts/check-pr-policy.py`, hard-fails CI): new sources are vetted live against the GitHub API (archived flag, last-push age, fork warning); new skills fail if named after a project/brand (they must be task-oriented) or if they reference a `docs/sources/<x>/` directory the PR doesn't provide; new bundled doc files that look like marketing pages or duplicate generic Cardano-101 content produce warnings.
2. **AI scope review** (advisory, never fails CI): when a PR adds a source or skill, a model judges it against the scope policy above — the two-part source test and the skill bar — and posts a review comment with a verdict and concrete requested changes. The rubric lives in `.github/scope-review-prompt.md`; the model call is a single non-agentic Gemini request (`.github/scripts/scope-review.py`) authenticated by a `GEMINI_API_KEY` repository secret (Google AI Studio keys have a free tier). When the secret is not configured the job skips cleanly and only the mechanical layer runs. The comment is advisory: a maintainer always makes the final call.

Run the mechanical layer locally before opening a PR:

```bash
python3 scripts/check-pr-policy.py            # compares HEAD against origin/main
```

If a check misfires (e.g. a legitimately-named skill trips the brand heuristic), say so in the PR description — the maintainer can merge over a failing policy check.

## Adding a new documentation source

### 1. Verify against the vetting policy above

### 2. Edit `registry/sources.yaml`

```yaml
- name: Project Name
  repo: https://github.com/org/repo.git
  docs_path: docs                    # path within the repo containing docs
  format: markdown                   # see "Valid values" below
  category: infrastructure           # see "Valid values" below
  priority: medium                   # high, medium, low
  description: Short description of the project
  # Optional:
  # website: https://project.dev
  # branch: main
  # glob_patterns:
  #   - "**/*.md"
  # format_overrides:
  #   "**/*.yaml": openapi
  # vetting_exception: >-             # document-of-record repos only, granted
  #   why cadence is uninformative     # in VETTING_EXCEPTIONS in validate.py
```

**Valid `format` values:** `markdown`, `mdx`, `rst`, `openapi`, `aiken`, `python`, `toml`, `go`

`python` and `go` mirror source files rather than prose, so agents read the API
reference out of docstrings and doc comments. For those, scope `glob_patterns`
to the importable public surface — Go's `internal/` cannot be imported by
consumers, and `cmd/` holds CLI entry points, so neither belongs in a mirror.
Test files and `testdata/` fixture directories are dropped automatically
(`SKIP_FILE_SUFFIXES` and `SKIP_DIRS` in `scripts/_fetch_docs.py`), since
`glob_patterns` is include-only and cannot express an exclusion.

Never mirror an upstream `AGENTS.md` or `CLAUDE.md`. Bundled docs are read by
agents on every consumer's machine, so upstream agent instructions are an
injection vector; enumerate the markdown you want instead of globbing `*.md` at
a repo root.

**Valid `category` values:** `infrastructure`, `smart-contracts`, `sdk`, `standards`, `governance`, `scaling`, `testing`, `oracles`

If you need a new category or format, propose it in the PR — both are checked by `scripts/validate.py` against an explicit allow-list.

### 3. Fetch and pin locally

```bash
./scripts/fetch-docs.sh --source "Project Name" --update-pins
```

Check that files were actually pulled (`docs/sources/<slug>/`) and that the count looks right.

`--update-pins` records the upstream commit in `registry/pins.yaml`, and **a new source is
pinned in the PR that registers it**. The pin is the only record of which upstream commit
the mirrored content came from; without one the source re-resolves to whatever the branch
tip is at fetch time, so what a reviewer approved and what later ships are not guaranteed
to match. Despite the "auto-generated" banner, `--update-pins` merges into the file rather
than rewriting it — a per-source run touches one line and leaves the others alone.
`validate.py` fails a registered source that has no pin.

### 4. Validate

```bash
python3 scripts/validate.py
```

Needs `pyyaml`, which is the only Python prerequisite in this repo; every script here
runs on Python 3.9+, the version stock macOS ships. `--paths-only` runs the Windows
path-portability check alone and needs no dependencies at all — keep that true when
editing `validate.py`, since the weekly refresh workflow gates on it without
installing anything, and CI runs that mode on 3.9 to catch it if it stops being true.

### 5. Open a PR

CI runs validation automatically. The weekly refresh workflow picks up the new source on its next Monday run.

## Adding a new skill

Skills live flat under `skills/<name>/SKILL.md`. No category subdirectories.

### 1. Scaffold

```bash
./scripts/new-skill.sh my-new-skill
```

This creates:

```
skills/my-new-skill/
├── SKILL.md          # template
└── references/       # deeper content (one level only)
```

### 2. Write the SKILL.md

```yaml
---
name: my-new-skill
description: >-
  What this skill does. Include 3-5 trigger phrases users would say.
allowed-tools: Read Grep Glob
disallowed-tools: WebFetch WebSearch
---

# my-new-skill

## When to use
- Specific scenario 1
- Specific scenario 2

## When NOT to use
- Wrong scenario (redirect to correct skill)

## Key principles
- Domain-specific principle 1
- Domain-specific principle 2

## Workflow

### Step 1: Name
Instructions...

### Step 2: Name
Instructions...

## References
- See [reference-name](references/file.md) for details
```

### 3. Quality checklist

- [ ] SKILL.md under 500 lines
- [ ] Name is kebab-case, max 64 chars
- [ ] `name:` matches directory name
- [ ] Description includes trigger phrases
- [ ] Has "When to use", "When NOT to use", "Key principles", "Workflow" sections
- [ ] No external service dependency — remains useful with local file read and
      search access; any public read-only evidence exception is recorded in
      DESIGN.md and has a per-item fallback
- [ ] Claude metadata keeps `allowed-tools: Read Grep Glob` (anything wider
      needs a reviewed exception in `scripts/validate.py`) and
      `disallowed-tools` includes `WebFetch WebSearch`
- [ ] Body uses host-neutral capability language rather than requiring Claude
      or Codex tool names
- [ ] Bundled-doc paths are written `../../docs/sources/...`, relative to
      `SKILL.md`, and exist (`validate.py` checks both outside fenced code); no
      host-specific environment variable appears in the shared body
- [ ] Required safety behavior is stated in the body, not only in
      host-specific frontmatter
- [ ] Any permitted public retrieval names its bounded endpoint/identifier
      sources, forbids private/local request payloads and executing fetched
      content, records provenance, respects host denial, and never widens
      permissions automatically
- [ ] Deep content in `references/`, one level only — no nested subdirectories
- [ ] States durable reasons rather than dates, counts, versions or popularity
      figures, unless the figure is fixed by nature and changes what the reader
      does (a version floor, a deliberate pin, a dated hard fork)
- [ ] No mention of specific deployed dApps; teach categories generically
- [ ] No mention of grants, treasuries, or governance proposals — the skill must read as a neutral community contribution

### 4. Validate and submit

```bash
python3 scripts/validate.py
```

Open a PR. CI runs validation and the PR policy checks.

## Verifying executable claims

When a change touches runnable content (validator code, CLI commands, ports, version pins),
verify it by running it, not just by cross-referencing docs. Note the bundled `docs/sources/`
mirror each project's upstream default branch, so check version-sensitive claims against
released packages (npm dist-tags, Maven metadata, GitHub releases), not the mirrored docs.

## Documentation governance

Docs (`AGENTS.md`, `CLAUDE.md`, `README.md`, `docs/DESIGN.md`,
`docs/CONTRIBUTING.md`, and `docs/AGENT_COMPATIBILITY.md`) must reflect current
state. When you change something **observable from outside the repo**, update
related docs in the same PR.

### What to update for each change type

| Change | Update these docs |
|---|---|
| New skill | README.md skills table; DESIGN.md if it changes the skill graph. Pages site skills catalog auto-regenerates on build. |
| New source | CONTRIBUTING.md only if introducing a new category or format. Pages site sources catalog auto-regenerates on build. |
| New schema field | `registry/sources.yaml` header comment; CONTRIBUTING.md valid-values lists; DESIGN.md if architectural |
| New script in `scripts/` | README.md if user-facing |
| New hook | README.md "How to set the Cardano context" section; CLAUDE.md repo structure; `website/src/content/docs/how-it-works.md` |
| Agent adapter, manifest, discovery, or portability rule | AGENTS.md; CLAUDE.md; `docs/AGENT_COMPATIBILITY.md`; README/website install docs when user-visible |
| Scope / vetting / governance policy change | CLAUDE.md; CONTRIBUTING.md; `website/src/content/docs/contributing/` pages |
| Vision / "why" change | README.md; `website/src/content/docs/about/why.md` |
| Install flow change | README.md install section; `website/src/content/docs/getting-started.md` |
| Roadmap change | `website/src/content/docs/about/roadmap.md` |
| Removed/renamed file | All docs that reference it — grep first |

Pure internal tweaks (refactor a script, fix a typo in a skill body) don't trigger doc updates.

## Refreshing content

The weekly workflow (`.github/workflows/refresh-docs.yml`) runs every Monday at 06:00 UTC, fetches every source's upstream branch tip, and opens a PR labeled `documentation, automated` with **one commit per changed source** (doc files + that source's line in `registry/pins.yaml` together), so a bad upstream delta can be reverted per source with a single `git revert`.

Outside the weekly refresh, `fetch-docs.sh` checks out the **pinned commit** recorded in `registry/pins.yaml` — not the branch tip — so what ships is exactly what passed refresh-PR screening. Never hand-edit a pin: write it with `--update-pins` so the recorded sha and the fetched content always agree. A source with no pin falls back to its branch tip; that fallback keeps a fetch working, but it is not a substitute for pinning a source when you register it (see step 3).

### Supply-chain screening

Bundled docs are read by AI agents on every consumer's machine, so every change to `docs/sources/` is screened before merge:

1. **Fetch-time sanitization** (`scripts/_fetch_docs.py`): zero-width/bidi characters stripped from all text files; HTML comments and `<script>` blocks stripped from markup — removes the hidden-text injection class outright.
2. **Mechanical delta scanner** (`scripts/scan-docs-delta.py`, blocking CI check in the PR Policy workflow): scans changed lines for agent-targeted injection phrasing, `curl | sh` installs, swapped bech32 addresses, changed install commands, base64 blobs, and URLs on domains a source never used before. Blocking findings turn the check red until a human clears them.
3. **Advisory AI docs-delta review** (PR Policy workflow, rubric in `.github/docs-delta-review-prompt.md`): a non-agentic model call classifies each source's delta as plausible maintenance vs injection/poisoning and posts a sticky per-source verdict table. Advisory — it informs the human decision, never replaces it.

A maintainer merges the refresh PR when the scan is green and the review raises nothing that needs a closer look. Run the scanner locally with `python3 scripts/scan-docs-delta.py --base origin/main`.

### Path portability

git aborts the **entire** checkout when a tree contains a path Windows cannot create — not just the offending file — so one badly named upstream doc locks every Windows user out of the repo. Upstream wiki exports hit this routinely (a page titled `cardano-node and DataPoints: demo` becomes a filename with a colon).

`scripts/_fetch_docs.py` normalizes fetched paths per component: `< > : " | ? * \` and control characters become `-`, trailing dots/spaces are stripped, reserved device names (`CON`, `NUL`, `COM1`…) get a `_` prefix, and a name that collides with one already taken — including case-only duplicates, which a case-insensitive Windows filesystem cannot distinguish — gets a `-2`, `-3` suffix. Renames are printed as `RENAMED <source>: <old> -> <new>`.

Backslash is in that set because it is a legal filename character on POSIX but a path separator on Windows — an upstream `notes\draft.md` breaks the checkout exactly like a colon does, while looking harmless in a Linux-side review.

`scripts/validate.py` re-checks every tracked path and fails the build on a violation. It is the backstop for hand-added files; the refresh workflow also runs it inline as `--paths-only`, because a PR opened with `GITHUB_TOKEN` never triggers the `pull_request` validate workflow. `--paths-only` skips the skill and registry checks (a docs refresh must not be blocked by an unrelated skill error) and is stdlib-only, so that job needs no `setup-python` or `pip install`.

Files added by hand must satisfy the same rules. Path length is checked too, as a warning above 200 characters — Windows' default `MAX_PATH` is 260 including the clone directory.

To trigger manually:

```bash
gh workflow run refresh-docs.yml
```

To refresh locally:

```bash
./scripts/fetch-docs.sh                          # all sources
./scripts/fetch-docs.sh --source "Source Name"   # one source
```

### When to refresh out of band

- Major SDK release changes APIs (e.g. Mesh v2, Evolution SDK breaking changes)
- New CIPs ratified that affect developer workflows
- New vulnerability patterns discovered
- A referenced tool is deprecated or replaced — drop the source AND update relevant skills

## Future automation (tracked, not yet built)

The planned automation is listed on the [roadmap](../website/src/content/docs/about/roadmap.md);
the rationale for each item is in [DESIGN.md Decision 9](DESIGN.md).
