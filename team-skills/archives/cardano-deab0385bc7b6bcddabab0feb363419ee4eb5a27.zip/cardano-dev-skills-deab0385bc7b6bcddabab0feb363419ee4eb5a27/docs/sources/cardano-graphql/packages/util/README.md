# Cardano GraphQL - Util
